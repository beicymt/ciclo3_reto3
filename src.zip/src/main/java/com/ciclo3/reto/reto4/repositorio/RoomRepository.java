package com.ciclo3.reto.reto4.repositorio;

import com.ciclo3.reto.reto4.entidad.Room;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoomRepository extends JpaRepository<Room, Long> {
}
