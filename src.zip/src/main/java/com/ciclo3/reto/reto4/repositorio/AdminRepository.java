package com.ciclo3.reto.reto4.repositorio;

import com.ciclo3.reto.reto4.entidad.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<Admin,Long> {
}
