package com.ciclo3.reto.reto4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Retog5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
